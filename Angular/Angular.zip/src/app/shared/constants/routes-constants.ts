export const ROUTE = {
  TEMPLATE: {
    TEMPLATE: {
      PATH: 'games',
    },
  },
};
