export interface IPagedResponse<Object> {
  totalElements: number;
  content: Object[];
}
