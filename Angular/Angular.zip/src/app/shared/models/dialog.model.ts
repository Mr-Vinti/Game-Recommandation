export interface Dialog {
  title: string;
  message: string;
  confirmationRequires: boolean;
}
