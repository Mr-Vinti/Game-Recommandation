export interface StringResponse {
    response: string;
}