export interface User {
    id: number;
    uuid: string;
}
