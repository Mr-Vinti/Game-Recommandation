export const environment = {
  production: true,
  baseHref: '/',
  apiResourceUri: 'https://url.com/game-rec/api',
};
