package com.org.acs.gr.util;

public class Constants {
	public static final Integer MAX_SAVE_BATCH_SIZE = 2010;
	public static final Integer MAX_BATCH_SIZE = 2000;
}
